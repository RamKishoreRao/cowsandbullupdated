import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cowsandbull',
  templateUrl: './cowsandbull.component.html',
  styleUrls: ['./cowsandbull.component.css']
})
export class CowsandbullComponent implements OnInit {
title :string;
lockword:string;
congrats:string;
bulls:number;
cows:number;
len:number;


  constructor() { }

  ngOnInit() {
    this.title ="Welcome to Cows&Bulls";
  }

  LockWord(){
  this.lockword = "what";
  }
  
  onEnter(word:string){
    this.cows=0;
    this.bulls=0;
    if(word===this.lockword){
      this.congrats="you won this game";
    }else{
      this.len=word.length;
      var i;
      var cow_count=0;
      var bull_count=0;
      for(i=0;i<this.len;i++){
         if(word[i]===this.lockword[i]) {
          this.cows=++cow_count;
         }else{
           var j;
           for(j=0;j<this.len;j++){
             if(word[i]===this.lockword[j]){
               this.bulls=++bull_count;
             }
           }
         }
      }
      this.congrats="please try again";
      




    }
       
  }


}
